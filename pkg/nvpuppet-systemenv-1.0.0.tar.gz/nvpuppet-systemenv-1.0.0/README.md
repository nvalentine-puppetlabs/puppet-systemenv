puppet-envvar
=============

Manage environment variables
